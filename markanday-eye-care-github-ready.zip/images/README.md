This folder includes lightweight transparent WebP placeholders so the site has no broken image requests before the client shares photography.

Replace them with the final optimized clinic photography before deployment.

Required files:

- `dr-ahuja.webp` - hero portrait of Dr. Markanday Ahuja, recommended 580x680.
- `dr-markanday-ahuja.webp` - doctor profile portrait, recommended 480x560.

Export as WebP, keep each file below 180 KB where possible, and preserve the filenames above so the HTML does not need to change. The site includes a styled fallback if either image is temporarily unavailable.
