# Markanday Eye Care Website

Premium static website for Markanday Eye Care, Rohtak, Haryana.

## Files

- `index.html` - semantic HTML, SEO metadata, schema, all website sections.
- `css/style.css` - responsive design system, layout, components, animations.
- `js/main.js` - header behavior, tabs, sliders, form validation, FAQ, counters.
- `images/` - transparent placeholder WebP files plus image placement instructions for final clinic photography.
- `.nojekyll` - keeps GitHub Pages from applying Jekyll processing.
- `.gitignore` - prevents macOS/system files from being uploaded.

## Run Locally

Open `index.html` directly in a browser, or serve the folder with any static web server.

Example:

```bash
python3 -m http.server 8080
```

Then visit `http://localhost:8080/markanday-eye-care/` if serving from the parent workspace.

## Upload to GitHub

Option 1: GitHub website upload

1. Create a new GitHub repository.
2. Open the `markanday-eye-care` folder.
3. Upload all files and folders inside it, including `.nojekyll`, `css`, `js`, and `images`.
4. Do not upload `.DS_Store`; it is ignored by `.gitignore`.

Option 2: Git command line

```bash
cd "markanday-eye-care"
git init
git add .
git commit -m "Initial Markanday Eye Care website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO-NAME.git
git push -u origin main
```

## GitHub Pages

After pushing to GitHub:

1. Go to repository Settings.
2. Open Pages.
3. Set Source to `Deploy from a branch`.
4. Select branch `main` and folder `/root`.
5. Save. GitHub will publish the site after a short build.

## Deployment Notes

- Replace the doctor image files in `images/` before launch.
- Update `info@markandayeyecare.com` if the client provides a final email address.
- Connect the appointment and contact forms to a backend or form service before production lead capture.
