const App = {
  q(selector, root) {
    const scope = root || document;
    return scope ? scope.querySelector(selector) : null;
  },

  qa(selector, root) {
    const scope = root || document;
    return scope ? Array.from(scope.querySelectorAll(selector)) : [];
  },

  init() {
    this.header();
    this.mobileMenu();
    this.counters();
    this.scrollAnimations();
    this.serviceTabs();
    this.testimonialSlider();
    this.multiStepForm();
    this.faqAccordion();
    this.trustBarScroll();
    this.footerYear();
    this.sundayDateBlock();
    this.contactForm();
    this.imageFallbacks();
  },

  header() {
    const header = this.q('#site-header');
    if (!header) return;

    let lastScrollY = window.scrollY;
    let ticking = false;

    const updateHeader = () => {
      const currentScroll = window.scrollY;
      header.classList.toggle('is-scrolled', currentScroll > 80);

      if (currentScroll > lastScrollY && currentScroll > 120) {
        header.classList.add('is-hidden');
      } else {
        header.classList.remove('is-hidden');
      }

      lastScrollY = currentScroll;
      ticking = false;
    };

    window.addEventListener('scroll', () => {
      if (!ticking) {
        window.requestAnimationFrame(updateHeader);
        ticking = true;
      }
    }, { passive: true });

    updateHeader();

    const navLinks = this.qa('.nav__link');
    const sections = this.qa('main section[id]');
    if (!navLinks.length || !sections.length || !('IntersectionObserver' in window)) return;

    const activeObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const id = entry.target.getAttribute('id');
        if (!id) return;

        navLinks.forEach((link) => {
          const href = link.getAttribute('href');
          link.classList.toggle('is-active', href === `#${id}`);
        });
      });
    }, {
      rootMargin: '-35% 0px -55% 0px',
      threshold: 0.1
    });

    sections.forEach((section) => {
      if (section) activeObserver.observe(section);
    });
  },

  mobileMenu() {
    const button = this.q('.nav__hamburger');
    const menu = this.q('#mobile-menu');
    if (!button || !menu) return;

    const links = this.qa('a', menu);

    const closeMenu = () => {
      button.classList.remove('is-open');
      button.setAttribute('aria-expanded', 'false');
      button.setAttribute('aria-label', 'Open menu');
      menu.classList.remove('is-open');
      menu.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    };

    const openMenu = () => {
      button.classList.add('is-open');
      button.setAttribute('aria-expanded', 'true');
      button.setAttribute('aria-label', 'Close menu');
      menu.classList.add('is-open');
      menu.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    };

    button.addEventListener('click', () => {
      if (button.classList.contains('is-open')) {
        closeMenu();
      } else {
        openMenu();
      }
    });

    links.forEach((link) => {
      if (link) link.addEventListener('click', closeMenu);
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && button.classList.contains('is-open')) closeMenu();
    });
  },

  counters() {
    const counters = this.qa('.stat__number');
    if (!counters.length || !('IntersectionObserver' in window)) {
      counters.forEach((counter) => {
        if (!counter) return;
        const count = Number(counter.dataset.count || '0');
        counter.textContent = String(count);
      });
      return;
    }

    const animateCounter = (counter) => {
      if (!counter) return;
      const target = Number(counter.dataset.count || '0');
      const duration = 1400;
      let startTime = null;

      const step = (timestamp) => {
        if (!startTime) startTime = timestamp;
        const progress = Math.min((timestamp - startTime) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        counter.textContent = String(Math.floor(eased * target));
        if (progress < 1) {
          window.requestAnimationFrame(step);
        } else {
          counter.textContent = String(target);
        }
      };

      window.requestAnimationFrame(step);
    };

    const counterObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.35 });

    counters.forEach((counter) => {
      if (counter) counterObserver.observe(counter);
    });
  },

  scrollAnimations() {
    const animated = this.qa('[data-animate]');
    if (!animated.length || !('IntersectionObserver' in window)) {
      animated.forEach((item) => {
        if (item) item.classList.add('is-visible');
      });
      return;
    }

    const observer = new IntersectionObserver((entries, instance) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        instance.unobserve(entry.target);
      });
    }, {
      rootMargin: '0px 0px -12% 0px',
      threshold: 0.08
    });

    animated.forEach((item) => {
      if (item) observer.observe(item);
    });
  },

  serviceTabs() {
    const tabRoot = this.q('.tabs');
    if (!tabRoot) return;

    const buttons = this.qa('[role="tab"]', tabRoot);
    const panels = this.qa('[role="tabpanel"]', tabRoot);
    if (!buttons.length || !panels.length) return;

    const activateTab = (button) => {
      if (!button) return;
      const panelId = button.getAttribute('aria-controls');
      if (!panelId) return;

      buttons.forEach((item) => {
        if (!item) return;
        const selected = item === button;
        item.classList.toggle('is-active', selected);
        item.setAttribute('aria-selected', selected ? 'true' : 'false');
      });

      panels.forEach((panel) => {
        if (!panel) return;
        const selected = panel.id === panelId;
        panel.hidden = !selected;
        panel.classList.toggle('is-active', selected);
      });
    };

    buttons.forEach((button) => {
      if (!button) return;
      button.addEventListener('click', () => activateTab(button));
      button.addEventListener('keydown', (event) => {
        const index = buttons.indexOf(button);
        if (event.key !== 'ArrowRight' && event.key !== 'ArrowLeft') return;
        event.preventDefault();
        const direction = event.key === 'ArrowRight' ? 1 : -1;
        const nextIndex = (index + direction + buttons.length) % buttons.length;
        const nextButton = buttons[nextIndex];
        if (nextButton) {
          nextButton.focus();
          activateTab(nextButton);
        }
      });
    });
  },

  testimonialSlider() {
    const slider = this.q('.testimonial-slider');
    if (!slider) return;

    const track = this.q('.testimonial-slider__track', slider);
    const viewport = this.q('.testimonial-slider__viewport', slider);
    const prev = this.q('[data-slider-prev]', slider);
    const next = this.q('[data-slider-next]', slider);
    const dotsWrap = this.q('.slider-dots', slider);
    const cards = this.qa('.testimonial-card', slider);
    if (!track || !viewport || !cards.length) return;

    let index = 0;
    let timer = null;
    let visibleCount = 1;
    let maxIndex = 0;

    const getVisibleCount = () => {
      if (window.innerWidth >= 920) return 3;
      if (window.innerWidth >= 760) return 2;
      return 1;
    };

    const buildDots = () => {
      if (!dotsWrap) return;
      dotsWrap.innerHTML = '';
      for (let i = 0; i <= maxIndex; i += 1) {
        const dot = document.createElement('button');
        dot.type = 'button';
        dot.className = 'slider-dot';
        dot.setAttribute('aria-label', `Go to testimonial ${i + 1}`);
        dot.addEventListener('click', () => {
          index = i;
          update();
          restart();
        });
        dotsWrap.appendChild(dot);
      }
    };

    const update = () => {
      visibleCount = Math.min(getVisibleCount(), cards.length);
      maxIndex = Math.max(cards.length - visibleCount, 0);
      index = Math.min(index, maxIndex);
      const card = cards[0];
      const styles = window.getComputedStyle(track);
      const gap = Number.parseFloat(styles.columnGap || styles.gap || '0') || 0;
      const cardWidth = card ? card.getBoundingClientRect().width : 0;
      track.style.transform = `translateX(-${index * (cardWidth + gap)}px)`;

      const dots = this.qa('.slider-dot', dotsWrap);
      dots.forEach((dot, dotIndex) => {
        if (!dot) return;
        dot.classList.toggle('is-active', dotIndex === index);
        dot.setAttribute('aria-current', dotIndex === index ? 'true' : 'false');
      });
    };

    const goNext = () => {
      if (maxIndex <= 0) return;
      index = index >= maxIndex ? 0 : index + 1;
      update();
    };

    const goPrev = () => {
      if (maxIndex <= 0) return;
      index = index <= 0 ? maxIndex : index - 1;
      update();
    };

    const pause = () => {
      if (timer) {
        window.clearInterval(timer);
        timer = null;
      }
    };

    const start = () => {
      pause();
      if (cards.length <= visibleCount) return;
      timer = window.setInterval(goNext, 5000);
    };

    const restart = () => {
      pause();
      start();
    };

    visibleCount = Math.min(getVisibleCount(), cards.length);
    maxIndex = Math.max(cards.length - visibleCount, 0);
    buildDots();
    update();
    start();

    if (prev) prev.addEventListener('click', () => { goPrev(); restart(); });
    if (next) next.addEventListener('click', () => { goNext(); restart(); });
    slider.addEventListener('mouseenter', pause);
    slider.addEventListener('mouseleave', start);
    slider.addEventListener('focusin', pause);
    slider.addEventListener('focusout', start);
    window.addEventListener('resize', () => {
      const previousMax = maxIndex;
      visibleCount = Math.min(getVisibleCount(), cards.length);
      maxIndex = Math.max(cards.length - visibleCount, 0);
      if (previousMax !== maxIndex) buildDots();
      update();
      restart();
    }, { passive: true });
  },

  multiStepForm() {
    const form = this.q('#appointment-form');
    if (!form) return;

    const steps = this.qa('.form-step', form);
    const nextButton = this.q('[data-form-next]', form);
    const backButton = this.q('[data-form-back]', form);
    const submitButton = this.q('[data-form-submit]', form);
    const stepLabel = this.q('#step-label');
    const progressBar = this.q('.form-progress__bar span', form);
    const success = this.q('#appointment-success');
    const summary = this.q('#appointment-summary');
    if (!steps.length || !nextButton || !backButton || !submitButton) return;

    let currentStep = 1;

    const setError = (id, message) => {
      const error = this.q(`#${id}`);
      if (error) error.textContent = message || '';
    };

    const setFieldInvalid = (fieldSelector, invalid) => {
      const field = this.q(fieldSelector, form);
      if (field) field.classList.toggle('is-invalid', invalid);
    };

    const getInput = (selector) => this.q(selector, form);

    const validatePhone = () => {
      const phone = getInput('#patient-phone');
      if (!phone) return false;
      const digits = phone.value.replace(/\D/g, '').slice(0, 10);
      phone.value = digits;
      const valid = /^\d{10}$/.test(digits);
      setError('phone-error', valid ? '' : 'Enter a valid 10-digit mobile number.');
      setFieldInvalid('.phone-field', !valid);
      return valid;
    };

    const validateEmail = () => {
      const email = getInput('#patient-email');
      if (!email || !email.value.trim()) {
        setError('email-error', '');
        setFieldInvalid('#patient-email', false);
        return true;
      }
      const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim());
      setError('email-error', valid ? '' : 'Enter a valid email address.');
      const emailField = email.closest('.field');
      if (emailField) emailField.classList.toggle('is-invalid', !valid);
      return valid;
    };

    const validateName = () => {
      const name = getInput('#patient-name');
      if (!name) return false;
      const valid = name.value.trim().length >= 2;
      setError('name-error', valid ? '' : 'Please enter the patient name.');
      const nameField = name.closest('.field');
      if (nameField) nameField.classList.toggle('is-invalid', !valid);
      return valid;
    };

    const validateDate = () => {
      const dateInput = getInput('#preferred-date');
      if (!dateInput) return false;
      if (!dateInput.value) {
        setError('date-error', 'Please select a preferred date.');
        const field = dateInput.closest('.field');
        if (field) field.classList.add('is-invalid');
        return false;
      }
      const selectedDate = new Date(`${dateInput.value}T00:00:00`);
      const isSunday = selectedDate.getDay() === 0;
      setError('date-error', isSunday ? 'We are closed on Sundays. Please select Monday to Saturday.' : '');
      const field = dateInput.closest('.field');
      if (field) field.classList.toggle('is-invalid', isSunday);
      if (isSunday) dateInput.value = '';
      return !isSunday;
    };

    const validateStep = (step) => {
      if (step === 1) {
        const nameValid = validateName();
        const phoneValid = validatePhone();
        const emailValid = validateEmail();
        return nameValid && phoneValid && emailValid;
      }

      if (step === 2) {
        const treatment = getInput('#treatment-required');
        const treatmentValid = treatment ? treatment.value.trim().length > 0 : false;
        setError('treatment-error', treatmentValid ? '' : 'Please select the treatment required.');
        const treatmentField = treatment ? treatment.closest('.field') : null;
        if (treatmentField) treatmentField.classList.toggle('is-invalid', !treatmentValid);

        const dateValid = validateDate();
        const time = this.q('input[name="preferredTime"]:checked', form);
        const timeValid = Boolean(time);
        setError('time-error', timeValid ? '' : 'Please choose a preferred time slot.');
        return treatmentValid && dateValid && timeValid;
      }

      return true;
    };

    const getValue = (selector) => {
      const input = getInput(selector);
      return input ? input.value.trim() : '';
    };

    const updateSummary = () => {
      if (!summary) return;
      const time = this.q('input[name="preferredTime"]:checked', form);
      const rows = [
        ['Name', getValue('#patient-name')],
        ['Phone', `+91 ${getValue('#patient-phone')}`],
        ['Email', getValue('#patient-email') || 'Not provided'],
        ['Age', getValue('#patient-age') || 'Not provided'],
        ['Treatment', getValue('#treatment-required')],
        ['Preferred Date', getValue('#preferred-date')],
        ['Preferred Time', time ? time.value : 'Not selected'],
        ['City / Area', getValue('#patient-city') || 'Not provided']
      ];
      summary.innerHTML = `<dl>${rows.map((row) => `<div><dt>${row[0]}</dt><dd>${row[1]}</dd></div>`).join('')}</dl>`;
    };

    const showStep = (step) => {
      currentStep = Math.max(1, Math.min(step, steps.length));
      steps.forEach((item) => {
        if (!item) return;
        const isActive = Number(item.dataset.step) === currentStep;
        item.hidden = !isActive;
        item.classList.toggle('is-active', isActive);
      });

      if (stepLabel) stepLabel.textContent = `Step ${currentStep} of ${steps.length}`;
      if (progressBar) progressBar.style.width = `${(currentStep / steps.length) * 100}%`;
      backButton.hidden = currentStep === 1;
      nextButton.hidden = currentStep === steps.length;
      submitButton.hidden = currentStep !== steps.length;
      if (currentStep === steps.length) updateSummary();
    };

    const resetForm = () => {
      form.reset();
      this.qa('.field-error', form).forEach((error) => {
        if (error) error.textContent = '';
      });
      this.qa('.is-invalid', form).forEach((field) => {
        if (field) field.classList.remove('is-invalid');
      });
      showStep(1);
    };

    const name = getInput('#patient-name');
    const phone = getInput('#patient-phone');
    const email = getInput('#patient-email');
    const date = getInput('#preferred-date');
    if (name) name.addEventListener('blur', validateName);
    if (phone) {
      phone.addEventListener('input', () => {
        phone.value = phone.value.replace(/\D/g, '').slice(0, 10);
      });
      phone.addEventListener('blur', validatePhone);
    }
    if (email) email.addEventListener('blur', validateEmail);
    if (date) date.addEventListener('change', validateDate);

    nextButton.addEventListener('click', () => {
      if (!validateStep(currentStep)) return;
      showStep(currentStep + 1);
    });

    backButton.addEventListener('click', () => {
      showStep(currentStep - 1);
    });

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!validateStep(1) || !validateStep(2)) {
        showStep(!validateStep(1) ? 1 : 2);
        return;
      }

      submitButton.disabled = true;
      submitButton.textContent = 'Submitting...';
      const patientName = getValue('#patient-name');
      const patientPhone = getValue('#patient-phone');

      window.requestAnimationFrame(() => {
        if (success) {
          success.hidden = false;
          success.textContent = `Appointment Request Received! Thank you, ${patientName}. We will call you at +91 ${patientPhone} within a few hours to confirm. Clinic: Mon-Sat, 9AM-6PM | +91 98965 53294 | +91 89509 81653`;
          success.scrollIntoView({ behavior: 'smooth', block: 'center' });
          success.focus({ preventScroll: true });
        }
        submitButton.disabled = false;
        submitButton.textContent = 'Confirm My Appointment';
        resetForm();
      });
    });

    showStep(1);
  },

  faqAccordion() {
    const detailsItems = this.qa('.faq-list details');
    if (!detailsItems.length) return;

    detailsItems.forEach((details) => {
      if (!details) return;
      const summary = this.q('summary', details);
      const content = this.q('div', details);
      if (!summary || !content) return;

      summary.addEventListener('click', (event) => {
        event.preventDefault();

        if (details.classList.contains('is-open')) {
          content.style.maxHeight = `${content.scrollHeight}px`;
          window.requestAnimationFrame(() => {
            details.classList.remove('is-open');
            content.style.maxHeight = '0px';
          });
          content.addEventListener('transitionend', () => {
            if (!details.classList.contains('is-open')) details.open = false;
          }, { once: true });
        } else {
          details.open = true;
          window.requestAnimationFrame(() => {
            details.classList.add('is-open');
            content.style.maxHeight = `${content.scrollHeight}px`;
          });
        }
      });
    });
  },

  trustBarScroll() {
    const track = this.q('.trust-bar__track');
    if (!track) return;

    let timer = null;

    const pause = () => {
      if (timer) {
        window.clearInterval(timer);
        timer = null;
      }
    };

    const start = () => {
      pause();
      timer = window.setInterval(() => {
        const maxScroll = track.scrollWidth - track.clientWidth;
        if (maxScroll <= 0) return;
        if (track.scrollLeft >= maxScroll - 2) {
          track.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          track.scrollBy({ left: 220, behavior: 'smooth' });
        }
      }, 2600);
    };

    track.addEventListener('mouseenter', pause);
    track.addEventListener('mouseleave', start);
    track.addEventListener('focusin', pause);
    track.addEventListener('focusout', start);
    start();
  },

  footerYear() {
    const year = this.q('#footer-year');
    if (year) year.textContent = String(new Date().getFullYear());
  },

  sundayDateBlock() {
    const dateInput = this.q('#preferred-date');
    if (!dateInput) return;

    dateInput.min = new Date().toISOString().split('T')[0];
    dateInput.addEventListener('change', function handleDateChange() {
      const msg = document.querySelector('#date-error');
      if (!this.value) return;
      const day = new Date(`${this.value}T00:00:00`).getDay();
      if (day === 0) {
        this.value = '';
        if (msg) msg.textContent = 'We are closed on Sundays. Please select Monday to Saturday.';
      } else if (msg) {
        msg.textContent = '';
      }
    });
  },

  contactForm() {
    const form = this.q('#contact-form');
    if (!form) return;

    const status = this.q('.contact-form__status', form);
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const name = this.q('#contact-name', form);
      const phone = this.q('#contact-phone', form);
      const message = this.q('#contact-message', form);
      if (!name || !phone || !message) return;
      if (!name.value.trim() || !phone.value.trim() || !message.value.trim()) {
        if (status) {
          status.hidden = false;
          status.textContent = 'Please fill your name, phone, and message.';
        }
        return;
      }
      form.reset();
      if (status) {
        status.hidden = false;
        status.textContent = 'Message received. The clinic will call you shortly.';
      }
    });
  },

  imageFallbacks() {
    const images = this.qa('.photo-fallback img');
    images.forEach((image) => {
      if (!image) return;
      image.addEventListener('error', () => {
        image.classList.add('is-broken');
      });
      if (image.complete && image.naturalWidth === 0) {
        image.classList.add('is-broken');
      }
    });
  }
};

document.addEventListener('DOMContentLoaded', () => App.init());
